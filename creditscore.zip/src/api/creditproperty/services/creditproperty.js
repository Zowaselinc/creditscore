'use strict';

/**
 * creditproperty service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::creditproperty.creditproperty');

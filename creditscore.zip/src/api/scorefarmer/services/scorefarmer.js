'use strict';

/**
 * scorefarmer service
 */

module.exports = { scorefarmer: async (body) => {
    console.log(body);
 
     return {"name":"hello its me"}

}};

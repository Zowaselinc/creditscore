module.exports = {
  routes: [
    {
     method: 'POST',
     path: '/scorefarmer',
     handler: 'scorefarmer.scorefarmer',
     config: {
       policies: [],
       middlewares: [],
     },
    },
  ],
};

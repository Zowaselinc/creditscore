'use strict';
const unparsed = require('koa-body/unparsed.js');
/**
 * A set of functions called "actions" for `scorefarmer`
 */

module.exports = {
  
  
  async scorefarmer(ctx, next) {


    const unparsedBody = ctx.request.body[unparsed];
   
    try {
      const data = await strapi
        .service("api::scorefarmer.scorefarmer")
        .scorefarmer(unparsedBody);
      console.log(data, "data");
      ctx.body = data;

    } catch (err) {
      ctx.badRequest("Post report controller error", { moreDetails: err });
    }
  },
};

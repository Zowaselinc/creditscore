'use strict';

/**
 * creditvariable controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::creditvariable.creditvariable');

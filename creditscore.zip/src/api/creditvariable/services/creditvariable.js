'use strict';

/**
 * creditvariable service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::creditvariable.creditvariable');

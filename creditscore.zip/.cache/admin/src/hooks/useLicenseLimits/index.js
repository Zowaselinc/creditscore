const useLicenseLimits = () => {};

export default useLicenseLimits;

export const GET_DATA = 'ContentManager/App/GET_DATA';
export const RESET_PROPS = 'ContentManager/App/RESET_PROPS';
export const SET_CONTENT_TYPE_LINKS = 'ContentManager/App/SET_CONTENT_TYPE_LINKS';

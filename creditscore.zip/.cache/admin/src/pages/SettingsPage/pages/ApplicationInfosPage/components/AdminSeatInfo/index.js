const AdminSeatInfo = () => {
  return null;
};

export default AdminSeatInfo;
